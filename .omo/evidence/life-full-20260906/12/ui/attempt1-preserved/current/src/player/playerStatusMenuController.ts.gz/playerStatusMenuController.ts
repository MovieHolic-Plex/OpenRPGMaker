import { LifeReconciliationError } from "@/project/lifeRecovery";
import { investSkillNode, resetSkillTree } from "@/project/growth/runtime";
import { promoteActor } from "@/project/sessionClass";
import { refreshGrowthVitals } from "@/project/growth/vitals";
import type { GrowthMenuTab } from "@/player/playerGrowthMenu";
import { store } from "@/project/store";
import { createSaveSnapshot, getSaveSlotStatus, listSaveSlots, saveToSlot, type SaveSlotIndex } from "@/player/saveSlots";
import { renderPlayerStatusMenu, statusMenuControls } from "@/player/playerStatusMenu";
import { updateStatusMenuDetailSelection } from "@/player/playerStatusMenuDetailRenderer";
import { animateStatusMenuPage, animateStatusMenuVitals, readStatusMenuVitals } from "@/player/playerStatusMenuMotion";
import {
  isStatusMenuGroupEntryId,
  listStatusMenuGroupCommandIds,
  listStatusMenuRailIds,
  statusMenuRailIdForCommand,
  type StatusMenuCommandId,
  type StatusMenuGroupEntryId,
  type StatusMenuRailId,
} from "@/player/playerStatusMenuModel";
import { reduceStatusMenuKeyboard, type RuntimeMenuKey } from "@/player/runtimeKeyboardMenu";
import { directionForKey, isCancelKey, isConfirmKey } from "@/player/keyBindings";
import type { RuntimeJuiceEvent } from "@/player/runtimeJuice";
import type { ActorInitialEquipment, SkillId } from "@/project/types";
import type { PlaySession } from "@/project/session";
import type { LifeLedgerTabId } from "@/player/lifeLedger";
import { createLifePlacementLiveReader } from "@/player/lifePlacementScene";
import { moveMonster, rejectPendingMonsterSkill, replacePendingMonsterSkill } from "@/project/monsterCollection";
import {
  adoptStatusMenuPanel,
  currentStatusMenu,
  statusMenuDetailActionButtons,
  wrapStatusMenuIndex,
} from "@/player/playerStatusMenuControllerDom";
import type { PlayerStatusMenuController, PlayerStatusMenuControllerOptions } from "@/player/playerStatusMenuControllerTypes";
import {
  equipStatusMenuItem,
  moveStatusMenuFormationActor,
  type StatusMenuMutationResult,
  toggleStatusMenuActorRow,
  unequipStatusMenuItem,
  useStatusMenuItem,
} from "@/player/playerStatusMenuMutations";

export function createPlayerStatusMenuController(options: PlayerStatusMenuControllerOptions): PlayerStatusMenuController {
  let selectedCommand: StatusMenuRailId = "items";
  // 접힌 그룹을 통해 들어온 경우의 부모 — 취소하면 레일이 아니라 그룹 목록으로 돌아간다.
  let openGroupId: StatusMenuGroupEntryId | undefined;
  let mode: "main" | "function" = "main";
  let selectedDetailActionIndex = 0;
  const detailCursors = new Map<string, number>();
  const detailScrolls = new Map<string, number>();
  let targetItemId: string | undefined;
  let skillActorId: string | undefined;
  let selectedSkillId: string | undefined;
  let growthTab: GrowthMenuTab = "skills";
  let equipmentActorId: string | undefined;
  let equipmentSlotId: keyof ActorInitialEquipment | undefined;
  let formationActorId: string | undefined;
  let monsterView: "party" | "box" = "party";
  let lifeLedgerTab: LifeLedgerTabId = "shipping";
  let confirmSaveSlot: SaveSlotIndex | undefined;
  let confirmToTitlePending = false;
  let waitModeEnabled = true;

  const reset = (): void => {
    selectedCommand = "items";
    openGroupId = undefined;
    mode = "main";
    selectedDetailActionIndex = 0;
    detailCursors.clear();
    detailScrolls.clear();
    waitModeEnabled = true;
    resetSubscreenState();
  };

  const resetSubscreenState = (): void => {
    selectedDetailActionIndex = 0;
    targetItemId = undefined;
    skillActorId = undefined;
    selectedSkillId = undefined;
    growthTab = "skills";
    equipmentActorId = undefined;
    equipmentSlotId = undefined;
    formationActorId = undefined;
    monsterView = "party";
    lifeLedgerTab = "shipping";
    confirmSaveSlot = undefined;
    confirmToTitlePending = false;
  };

  const replaceMenu = (panel: HTMLElement): HTMLElement => {
    panel.dataset.testid = "main-menu";
    const host = options.getPlayStage() ?? options.layout;
    const existing =
      host.querySelector<HTMLElement>("[data-testid='main-menu']")
      ?? options.layout.querySelector<HTMLElement>("[data-testid='main-menu']");
    if (!existing || existing.dataset.statusMenuClosing === "1") {
      existing?.remove();
      host.append(panel);
      return panel;
    }
    return adoptStatusMenuPanel(existing, panel);
  };

  const renderMenu = (message?: string, nextCommand: StatusMenuRailId = selectedCommand): HTMLElement | null => {
    const previous = currentMenu();
    const scroll = previous?.querySelector<HTMLElement>(".status-menu-detail-list")?.scrollTop;
    if (previous?.dataset.detailState && scroll !== undefined) detailScrolls.set(previous.dataset.detailState, scroll);
    const project = store.getCurrent();
    const session = options.getActiveScene()?.getSession();
    if (!session) return null;
    selectedCommand = nextCommand;
    selectedDetailActionIndex = detailCursors.get(detailStateKey()) ?? defaultDetailCursor();
    const panel = renderPlayerStatusMenu({
      project,
      session,
      slots: listSaveSlots(window.localStorage),
      message,
      elapsedMs: options.getPlayStartedAt() > 0 ? performance.now() - options.getPlayStartedAt() : 0,
      selectedCommand,
      mode,
      targetItemId,
      skillActorId,
      selectedSkillId,
      growthTab,
      equipmentActorId,
      equipmentSlotId,
      formationActorId,
      monsterView,
      lifeLedgerTab,
      readLive: createLifePlacementLiveReader(
        () => options.getActiveScene(),
        () => store.getCurrent(),
      ),
      placementDirection: options.getActiveScene()?.facing,
      getPlacementDirection: () => options.getActiveScene()?.facing,
      confirmSaveSlot,
      confirmToTitle: confirmToTitlePending,
      saveEnabled: isSaveEnabled(session),
      waitModeEnabled,
      selectedDetailActionIndex,
      actions: {
        onCommand: enterCommand,
        onOpenGroup: openGroup,
        onSaveSlot: saveSlot,
        onLoadSlot: loadSlot,
        onSelectItemTarget: (itemId) => {
          rememberDetailCursorFromTestId(`status-menu-item-${itemId}`);
          targetItemId = itemId;
          options.emitMenuJuice("menu-confirm", renderMenu(undefined, "items"));
        },
        onUseItem: useItem,
        onSelectSkillActor: (actorId) => {
          rememberDetailCursorFromTestId(`status-menu-skill-actor-${actorId}`);
          skillActorId = actorId;
          selectedSkillId = undefined;
          options.emitMenuJuice("menu-confirm", renderMenu(undefined, "skills"));
        },
        onSelectGrowthTab: (tab) => { growthTab = tab; selectedDetailActionIndex = 0; options.emitMenuJuice("menu-select", renderMenu(undefined, "skills")); },
        onGrowthMutation: (action) => {
          const scene = options.getActiveScene(); if (!scene) return;
          const project = store.getCurrent(), session = scene.getSession();
          let error: string | undefined;
          if (action.kind === "invest") error = investSkillNode(project, session, action.actorId, action.treeId, action.nodeId);
          else if (action.kind === "reset") error = resetSkillTree(project, session, action.actorId, action.treeId);
          else { const result = promoteActor(session, project, action.actorId, action.classId); if (!result.ok) error = "승급 조건을 만족하지 못했습니다."; }
          refreshGrowthVitals(project, session, action.actorId);
          scene.syncRuntimeState();
          options.emitMenuJuice("menu-confirm", renderMenu(error ?? (action.kind === "invest" ? "능력을 습득했습니다." : action.kind === "reset" ? "포인트를 환급했습니다." : "새로운 직업으로 승급했습니다."), "skills"));
        },
        onSelectSkill: (skillId) => {
          if (skillActorId) rememberDetailCursorFromTestId(`status-menu-skill-${skillActorId}-${skillId}`);
          selectedSkillId = skillId;
          options.emitMenuJuice("menu-select", renderMenu(undefined, "skills"));
        },
        onSelectEquipmentActor: (actorId) => {
          rememberDetailCursorFromTestId(`status-menu-equipment-actor-${actorId}`);
          equipmentActorId = actorId;
          equipmentSlotId = undefined;
          options.emitMenuJuice("menu-confirm", renderMenu(undefined, "equipment"));
        },
        onSelectEquipmentSlot: (actorId, slotId) => {
          rememberDetailCursorFromTestId(`status-menu-equipment-slot-${slotId}`);
          equipmentActorId = actorId;
          equipmentSlotId = slotId;
          options.emitMenuJuice("menu-confirm", renderMenu(undefined, "equipment"));
        },
        onEquipItem: equipItem,
        onUnequipItem: unequipItem,
        onToggleRow: toggleActorRow,
        onSelectFormationActor: (actorId) => {
          rememberDetailCursorFromTestId(`status-menu-formation-actor-${actorId}`);
          formationActorId = actorId;
          options.emitMenuJuice("menu-confirm", renderMenu(undefined, "formation"));
        },
        onMoveFormationActor: moveFormationActor,
        onToggleMonsterView: toggleMonsterView,
        onMoveMonster: moveMonsterFromMenu,
        onReplacePendingMonsterSkill: replaceMonsterSkillFromMenu,
        onRejectPendingMonsterSkill: rejectMonsterSkillFromMenu,
        onSelectLifeLedgerTab: (tab) => {
          rememberDetailCursorFromTestId(`life-ledger-tab-${tab}`);
          lifeLedgerTab = tab;
          options.emitMenuJuice("menu-select", renderMenu(undefined, "life-ledger"));
        },
        onLifeLedgerMutation: (ok, message) => {
          const scene = options.getActiveScene();
          scene?.refreshRuntimeSurfaces();
          scene?.syncRuntimeState();
          options.emitMenuJuice(ok ? "menu-confirm" : "menu-invalid", renderMenu(message, "life-ledger"));
        },
        onToggleWait: toggleWaitMode,
        onToTitle: confirmToTitle,
      },
    });
    panel.dataset.detailState = detailStateKey();
    const changedPage = currentMenu()?.dataset.detailState !== panel.dataset.detailState;
    const live = replaceMenu(panel);
    if (changedPage && currentMenu()) animateStatusMenuPage(live);
    syncRenderedDetailCursor();
    const list = live.querySelector<HTMLElement>(".status-menu-detail-list");
    const savedScroll = detailScrolls.get(detailStateKey());
    if (list && savedScroll !== undefined) list.scrollTop = savedScroll;
    return live;
  };

  const openSaveMenu = (): void => {
    reset();
    // 이벤트 진입은 레일 선택만 바꾸지 않고 저장 슬롯에 바로 포커스를 준다.
    // 저장 가능 여부는 렌더링과 saveSlot의 기존 맵/세션 제한을 그대로 따른다.
    mode = "function";
    options.emitMenuJuice("menu-open", renderMenu(undefined, "save"));
  };
  function focusMenuArea(nextMode: "main" | "function"): void {
    mode = nextMode;
    const menu = currentMenu();
    if (!menu) return;
    menu.dataset.statusMenuScreen = mode;
    menu.classList.toggle("status-menu-detail-focus", mode === "function");
    const detail = menu.querySelector<HTMLElement>(".status-menu-detail");
    if (mode === "main") detail?.setAttribute("inert", "");
    else detail?.removeAttribute("inert");
    const controls = menu.querySelector<HTMLElement>(".status-menu-controls");
    if (controls) controls.textContent = statusMenuControls(mode);
    const debug = menu.querySelector<HTMLElement>("[data-testid='status-menu-debug-json']");
    if (debug) debug.textContent = JSON.stringify({ selectedCommand, mode });
    focusActiveMenuContainer();
  }


  const toggleMenu = (): void => {
    if (!options.getActiveScene()) return;
    const session = options.getActiveScene()?.getSession();
    if (session?.m2Runtime?.access?.menu === false && !currentMenu()) return;
    const menu = currentMenu();
    if (menu?.dataset.statusMenuScreen === "function") {
      backOneStep();
      return;
    }
    if (menu) {
      options.closeMenuWithJuice();
      return;
    }
    mode = "main";
    selectedCommand = statusMenuRailIdForCommand(selectedCommand);
    openGroupId = undefined;
    resetSubscreenState();
    options.emitMenuJuice("menu-open", renderMenu());
  };

  const handleKey = (key: RuntimeMenuKey): boolean => {
    if (!currentMenu()) return false;
    const direction = directionForKey(key);
    if (mode === "function") {
      if (direction === "left") {
        focusMenuArea("main");
        options.emitMenuJuice("menu-back", currentMenu());
        return true;
      }
      if (direction === "right") return true;
      if (isDetailNavKey(key)) return moveSelectedDetailAction(detailDelta(key)) ? emitAndHandle("menu-select") : rejectInput();
      if (isConfirmMenuKey(key)) return activateSelectedDetailAction() || rejectInput();
      if (isCancelMenuKey(key)) {
        backOneStep();
        return true;
      }
      return rejectInput();
    }

    if (direction === "right" || isConfirmMenuKey(key)) {
      if (isStatusMenuGroupEntryId(selectedCommand)) openGroupId = selectedCommand;
      focusMenuArea("function");
      options.emitMenuJuice("menu-confirm", currentMenu());
      return true;
    }
    if (direction === "left") return true;

    if (isRailNavKey(key)) {
      // Horizontal input moves focus between the rail and its preview.
      const railDir = directionForKey(key);
      const railKey: RuntimeMenuKey =
        railDir === "right" || railDir === "down" ? "ArrowDown" : "ArrowUp";
      const session = options.getActiveScene()?.getSession();
      const commandIds = session
        ? listStatusMenuRailIds(store.getCurrent(), session)
        : undefined;
      const next = reduceStatusMenuKeyboard({ selectedCommand: statusMenuRailIdForCommand(selectedCommand), mode, commandIds }, railKey);
      if (commandIds && !commandIds.includes(next.selectedCommand)) {
        selectedCommand = commandIds[0] ?? "items";
      } else {
        selectedCommand = next.selectedCommand;
      }
      resetSubscreenState();
      openGroupId = undefined;
      renderMenu(undefined, selectedCommand);
      return emitAndHandle("menu-select");
    }
    if (isCancelMenuKey(key)) {
      options.closeMenuWithJuice();
      return true;
    }
    return false;
  };

  function saveSlot(slot: SaveSlotIndex): void {
    const scene = options.getActiveScene();
    if (!scene) return;
    rememberDetailCursorFromTestId(`save-slot-${slot}`);
    if (!isSaveEnabled(scene.getSession())) {
      rejectInput("지금은 저장할 수 없습니다");
      return;
    }
    const slots = listSaveSlots(window.localStorage);
    const slotState = getSaveSlotStatus(slots, slot);
    if (slotState.kind === "present" && confirmSaveSlot !== slot) {
      confirmSaveSlot = slot;
      options.emitMenuJuice("menu-confirm", renderMenu(`${slot}번 저장 칸을 덮어쓰려면 다시 선택하세요`, "save"));
      return;
    }
    confirmSaveSlot = undefined;
    confirmToTitlePending = false;
    let snapshot;
    try {
      snapshot = createSaveSnapshot(store.getCurrent(), scene.getSession());
    } catch (error) {
      if (!(error instanceof LifeReconciliationError)) throw error;
      rejectInput(`${slot}번 저장 칸에 저장하지 못했습니다`);
      return;
    }
    const written = saveToSlot(window.localStorage, slot, snapshot);
    if (!written.ok) {
      rejectInput(`${slot}번 저장 칸에 저장하지 못했습니다 — ${written.message}`);
      return;
    }
    options.emitMenuJuice("menu-confirm", renderMenu(`${slot}번 저장 칸에 저장했습니다`, "save"));
  }

  function loadSlot(slot: SaveSlotIndex): void {
    rememberDetailCursorFromTestId(`load-slot-${slot}`);
    options.emitMenuJuice("menu-confirm", currentMenu());
    options.loadSlot(slot, false);
  }

  function useItem(itemId: string, actorId?: string, monsterInstanceId?: string): void {
    const scene = options.getActiveScene();
    if (!scene) return;
    if (actorId) rememberDetailCursorFromTestId(`status-menu-item-target-${actorId}`);
    if (monsterInstanceId) rememberDetailCursorFromTestId(`status-menu-monster-${monsterInstanceId}`);
    const beforeVitals = readStatusMenuVitals(currentMenu());
    const result = useStatusMenuItem(scene, itemId, actorId, monsterInstanceId);
    if (result.kind === "used" && (scene.getSession().inventory[itemId] ?? 0) === 0) targetItemId = undefined;
    const panel = renderMenu(result.message, "items");
    if (panel && result.kind === "used") animateStatusMenuVitals(panel, beforeVitals);
    emitMutationResult(result, panel);
  }

  function equipItem(actorId: string, slotId: keyof ActorInitialEquipment, equipmentId: string): void {
    const scene = options.getActiveScene();
    if (!scene) return;
    rememberDetailCursorFromTestId(`status-menu-equipment-item-${equipmentId}`);
    const result = equipStatusMenuItem(scene, actorId, slotId, equipmentId);
    if (result.kind === "used") equipmentSlotId = undefined;
    emitMutationResult(result, renderMenu(result.message, "equipment"));
  }

  function unequipItem(actorId: string, slotId: keyof ActorInitialEquipment): void {
    const scene = options.getActiveScene();
    if (!scene) return;
    rememberDetailCursorFromTestId("status-menu-equipment-item-none");
    const result = unequipStatusMenuItem(scene, actorId, slotId);
    if (result.kind === "used") equipmentSlotId = undefined;
    emitMutationResult(result, renderMenu(result.message, "equipment"));
  }

  function toggleActorRow(actorId: string): void {
    const scene = options.getActiveScene();
    if (!scene) return;
    rememberDetailCursorFromTestId(`status-menu-row-${actorId}`);
    const result = toggleStatusMenuActorRow(scene, actorId);
    emitMutationResult(result, renderMenu(result.message, "row"));
  }

  function moveFormationActor(actorId: string, targetIndex: number): void {
    const scene = options.getActiveScene();
    if (!scene) return;
    const targetActorId = scene.getSession().partyActorIds[targetIndex];
    if (targetActorId) rememberDetailCursorFromTestId(`status-menu-formation-actor-${targetActorId}`);
    const result = moveStatusMenuFormationActor(scene, actorId, targetIndex);
    emitMutationResult(result, renderMenu(result.message, "formation"));
  }

  function toggleMonsterView(): void {
    monsterView = monsterView === "party" ? "box" : "party";
    options.emitMenuJuice("menu-confirm", renderMenu(undefined, "monsters"));
  }

  function moveMonsterFromMenu(instanceId: string, to: "party" | "box"): void {
    const scene = options.getActiveScene();
    if (!scene) return;
    rememberDetailCursorFromTestId(`status-menu-monster-${instanceId}`);
    const result = moveMonster(scene.getSession(), instanceId, to, store.getCurrent());
    const message = result.ok
      ? to === "party" ? "몬스터를 파티로 이동했습니다" : "몬스터를 보관함으로 이동했습니다"
      : result.reason === "partyFull" ? "파티가 가득 찼습니다" : "몬스터를 찾을 수 없습니다";
    options.emitMenuJuice(result.ok ? "menu-confirm" : "menu-invalid", renderMenu(message, "monsters"));
  }

  function replaceMonsterSkillFromMenu(instanceId: string, pendingSkillId: string, replacedSkillId: string): void {
    const scene = options.getActiveScene();
    if (!scene) return;
    const session = scene.getSession();
    const instance = session.monsterInstances[instanceId];
    if (!instance) {
      rejectInput("몬스터를 찾을 수 없습니다");
      return;
    }
    const result = replacePendingMonsterSkill(
      store.getCurrent(),
      instance,
      pendingSkillId as SkillId,
      replacedSkillId as SkillId,
    );
    if (result.ok) session.monsterInstances[instanceId] = result.instance;
    options.emitMenuJuice(
      result.ok ? "menu-confirm" : "menu-invalid",
      renderMenu(result.ok ? "새 기술을 배웠습니다" : "기술 교체에 실패했습니다", "monsters"),
    );
  }

  function rejectMonsterSkillFromMenu(instanceId: string, pendingSkillId: string): void {
    const scene = options.getActiveScene();
    if (!scene) return;
    const session = scene.getSession();
    const instance = session.monsterInstances[instanceId];
    if (!instance) {
      rejectInput("몬스터를 찾을 수 없습니다");
      return;
    }
    const result = rejectPendingMonsterSkill(instance, pendingSkillId as SkillId);
    if (result.ok) session.monsterInstances[instanceId] = result.instance;
    options.emitMenuJuice(
      result.ok ? "menu-confirm" : "menu-invalid",
      renderMenu(result.ok ? "새 기술을 포기했습니다" : "기술 선택에 실패했습니다", "monsters"),
    );
  }

  function openGroup(entryId: StatusMenuGroupEntryId): void {
    selectedCommand = entryId;
    openGroupId = entryId;
    resetSubscreenState();
    mode = "function";
    options.emitMenuJuice("menu-confirm", renderMenu(undefined, entryId));
  }

  function enterCommand(commandId: StatusMenuRailId): void {
    if (isStatusMenuGroupEntryId(commandId)) {
      openGroup(commandId);
      return;
    }
    selectedCommand = commandId;
    switch (commandId) {
      case "wait":
        toggleWaitMode();
        return;
      case "to-title":
        confirmToTitle();
        return;
      case "save": {
        const scene = options.getActiveScene();
        if (scene && !isSaveEnabled(scene.getSession())) {
          rejectInput("지금은 저장할 수 없습니다");
          return;
        }
        resetSubscreenState();
        mode = "function";
        options.emitMenuJuice("menu-confirm", renderMenu(undefined, commandId));
        return;
      }
      case "items":
      case "skills":
      case "equipment":
      case "monsters":
      case "load":
      case "status":
      case "row":
      case "formation":
      case "quests":
      case "relationships":
      case "life-ledger":
        resetSubscreenState();
        mode = "function";
        options.emitMenuJuice("menu-confirm", renderMenu(undefined, commandId));
        return;
      default:
        assertNever(commandId);
    }
  }

  function toggleWaitMode(): void {
    waitModeEnabled = !waitModeEnabled;
    mode = "function";
    options.emitMenuJuice(
      "menu-confirm",
      renderMenu(`대기 방식을 ${waitModeEnabled ? "ON" : "OFF"}로 전환했습니다`, "wait")
    );
  }

  // RM2003식 취소 백스택: 후보 목록 -> 슬롯 -> 액터 -> 레일 -> 메뉴 닫기.
  // 하위 화면에서 돌아올 때 각 단계의 커서는 detailCursors에 저장해 이전 위치를 되살린다.
  function backOneStep(): void {
    if (stepBackWithinSubscreen()) {
      options.emitMenuJuice("menu-back", renderMenu(undefined, selectedCommand));
      return;
    }
    confirmSaveSlot = undefined;
    confirmToTitlePending = false;
    // 접힌 그룹을 통해 들어왔으면 레일이 아니라 그룹 목록으로 한 단 돌아간다.
    if (openGroupId && !isStatusMenuGroupEntryId(selectedCommand) && groupContains(openGroupId, selectedCommand)) {
      selectedCommand = openGroupId;
      options.emitMenuJuice("menu-back", renderMenu(undefined, selectedCommand));
      return;
    }
    selectedCommand = statusMenuRailIdForCommand(selectedCommand);
    openGroupId = undefined;
    mode = "main";
    options.emitMenuJuice("menu-back", renderMenu(undefined, selectedCommand));
  }

  function groupContains(entryId: StatusMenuGroupEntryId, commandId: StatusMenuCommandId): boolean {
    const session = options.getActiveScene()?.getSession();
    if (!session) return false;
    return listStatusMenuGroupCommandIds(entryId, store.getCurrent(), session).includes(commandId);
  }

  function stepBackWithinSubscreen(): boolean {
    // 그룹 목록 화면에는 되돌릴 하위 단계가 없다.
    if (isStatusMenuGroupEntryId(selectedCommand)) return false;
    switch (selectedCommand) {
      case "items":
        if (targetItemId) {
          targetItemId = undefined;
          return true;
        }
        return false;
      case "skills":
        if (selectedSkillId) {
          selectedSkillId = undefined;
          return true;
        }
        if (skillActorId) {
          skillActorId = undefined;
          return true;
        }
        return false;
      case "equipment":
        if (equipmentSlotId) {
          equipmentSlotId = undefined;
          return true;
        }
        if (equipmentActorId) {
          equipmentActorId = undefined;
          return true;
        }
        return false;
      case "save":
        if (confirmSaveSlot) {
          confirmSaveSlot = undefined;
          return true;
        }
        return false;
      case "formation":
        if (formationActorId) {
          formationActorId = undefined;
          return true;
        }
        return false;
      case "monsters":
        return false;
      case "load":
      case "quests":
      case "relationships":
      case "life-ledger":
      case "row":
      case "status":
      case "to-title":
      case "wait":
        return false;
    }
  }

  function confirmToTitle(): void {
    if (!confirmToTitlePending) {
      confirmToTitlePending = true;
      mode = "function";
      options.emitMenuJuice(
        "menu-confirm",
        renderMenu("저장하지 않은 진행은 사라집니다. 한 번 더 선택하세요.", "to-title")
      );
      return;
    }
    confirmToTitlePending = false;
    options.emitMenuJuice("menu-confirm", currentMenu());
    window.setTimeout(() => options.renderTitle(), options.menuCloseJuiceMs);
  }

  const currentMenu = (): HTMLElement | null => currentStatusMenu(options.layout);

  function moveSelectedDetailAction(delta: -1 | 1): boolean {
    const actions = detailActionButtons();
    if (mode !== "function" || actions.length === 0) return false;
    setDetailCursor(wrapStatusMenuIndex(selectedDetailActionIndex + delta, actions.length));
    syncRenderedDetailCursor();
    const detail = currentMenu()?.querySelector<HTMLElement>(".status-menu-detail");
    const message = currentMenu()?.querySelector<HTMLElement>(".status-menu-message");
    if (detail && message) message.textContent = updateStatusMenuDetailSelection(detail, selectedDetailActionIndex) ?? "";
    return true;
  }

  function activateSelectedDetailAction(): boolean {
    const actions = detailActionButtons();
    if (mode !== "function" || actions.length === 0) return false;
    setDetailCursor(wrapStatusMenuIndex(selectedDetailActionIndex, actions.length));
    const reason = actions[selectedDetailActionIndex]?.dataset.unavailableReason;
    if (reason) return rejectInput(reason);
    actions[selectedDetailActionIndex]?.click();
    return true;
  }

  function detailActionButtons(): HTMLButtonElement[] {
    return statusMenuDetailActionButtons(options.layout);
  }

  function emitAndHandle(event: RuntimeJuiceEvent): boolean {
    options.emitMenuJuice(event);
    return true;
  }

  function rejectInput(message = "선택할 수 없습니다"): true {
    const panel = currentMenu();
    const status = panel?.querySelector<HTMLElement>(".status-menu-message");
    if (status) status.textContent = message;
    options.emitMenuJuice("menu-invalid", panel);
    return true;
  }

  function emitMutationResult(result: StatusMenuMutationResult, target?: HTMLElement | null): void {
    options.emitMenuJuice(result.kind === "used" ? "menu-confirm" : "menu-invalid", target ?? currentMenu());
  }

  function rememberDetailCursorFromTestId(testId: string): void {
    const element = currentMenu()?.querySelector<HTMLElement>(`[data-testid="${testId}"]`);
    const actionIndex = Number(element?.dataset.actionIndex);
    if (!Number.isFinite(actionIndex)) return;
    setDetailCursor(actionIndex);
  }

  function setDetailCursor(index: number): void {
    selectedDetailActionIndex = Math.max(0, index);
    detailCursors.set(detailStateKey(), selectedDetailActionIndex);
  }

  function syncRenderedDetailCursor(): void {
    const actions = detailActionButtons();
    if (actions.length === 0) {
      setDetailCursor(0);
      focusActiveMenuContainer();
      return;
    }
    selectedDetailActionIndex = Math.max(0, Math.min(selectedDetailActionIndex, actions.length - 1));
    detailCursors.set(detailStateKey(), selectedDetailActionIndex);
    actions.forEach((action, index) => {
      const selected = index === selectedDetailActionIndex;
      action.classList.toggle("selected", selected);
      action.tabIndex = selected ? 0 : -1;
      action.setAttribute("aria-current", selected ? "true" : "false");
    });
    const detailList = currentMenu()?.querySelector<HTMLElement>(".status-menu-detail-list");
    const activeAction = actions[selectedDetailActionIndex];
    if (detailList && activeAction?.id) detailList.setAttribute("aria-activedescendant", activeAction.id);
    actions[selectedDetailActionIndex]?.scrollIntoView({ block: "nearest" });
    focusActiveMenuContainer();
  }

  function focusActiveMenuContainer(): void {
    const menu = currentMenu();
    const target = mode === "function"
      ? menu?.querySelector<HTMLElement>(".status-menu-detail-list")
        ?? menu?.querySelector<HTMLElement>(".status-menu-detail")
      : menu?.querySelector<HTMLElement>(".status-menu-command-rail");
    if (typeof target?.focus === "function") target.focus({ preventScroll: true });
  }

  function detailStateKey(): string {
    if (isStatusMenuGroupEntryId(selectedCommand)) return `group:${selectedCommand}`;
    switch (selectedCommand) {
      case "items":
        return targetItemId ? `items:${targetItemId}:targets` : "items:list";
      case "skills":
        return skillActorId ? `skills:${skillActorId}:${growthTab}` : "skills:actors";
      case "equipment":
        if (!equipmentActorId) return "equipment:actors";
        if (!equipmentSlotId) return `equipment:${equipmentActorId}:slots`;
        return `equipment:${equipmentActorId}:${equipmentSlotId}:choices`;
      case "formation":
        return formationActorId ? "formation:moving" : "formation:list";
      case "monsters":
        return `monsters:${monsterView}`;
      case "save":
      case "load":
      case "quests":
      case "relationships":
      case "life-ledger":
      case "row":
      case "status":
      case "to-title":
      case "wait":
        return selectedCommand === "life-ledger" ? `life-ledger:${lifeLedgerTab}` : selectedCommand;
    }
  }

  function defaultDetailCursor(): number {
    if (selectedCommand === "formation" && formationActorId) {
      return Math.max(0, options.getActiveScene()?.getSession().partyActorIds.indexOf(formationActorId) ?? 0);
    }
    if (selectedCommand === "save" && confirmSaveSlot) return confirmSaveSlot - 1;
    return 0;
  }

  function isSaveEnabled(session: PlaySession): boolean {
    if (store.getCurrent().maps[session.currentMapId]?.disableSave === true) return false;
    return session.m2Runtime?.access.save !== false;
  }

  return { reset, renderMenu, openSaveMenu, toggleMenu, handleKey };
}

function isRailNavKey(key: RuntimeMenuKey): boolean {
  return directionForKey(key) !== null;
}

function isDetailNavKey(key: RuntimeMenuKey): boolean {
  return isRailNavKey(key);
}

function detailDelta(key: RuntimeMenuKey): -1 | 1 {
  const dir = directionForKey(key);
  return dir === "up" || dir === "left" ? -1 : 1;
}

// 확인/취소 판정은 정본에 위임한다. 여기서만 대문자 Z·X 를 놓쳐 CapsLock 상태에서
// 상태 메뉴만 먹통이 되던 결함(적대 리뷰 6).
function isConfirmMenuKey(key: RuntimeMenuKey): boolean {
  return isConfirmKey(key);
}

function isCancelMenuKey(key: RuntimeMenuKey): boolean {
  return isCancelKey(key);
}

function assertNever(value: never): never {
  throw new Error(`Unhandled status menu command: ${String(value)}`);
}
