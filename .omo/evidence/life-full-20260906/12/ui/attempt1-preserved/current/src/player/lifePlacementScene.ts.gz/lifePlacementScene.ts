import { resolvePlayerBody } from "@/project/playerFootprint";
import { runtimeEventViewsForMap, type RuntimeEventPositions } from "@/project/runtimeEventState";
import type {
  SpatialLiveActor,
  SpatialLiveContext,
  SpatialLiveContextReader,
} from "@/project/spatialOccupancy";
import type { PlaySession } from "@/project/session";
import type { Dir, GameMap, Project } from "@/project/types";

/** Scene projection is missing or not a discrete body. Live UI must refuse, not drop the reader. */
export class LifePlacementSceneUnavailableError extends Error {
  constructor() {
    super("life placement scene is unavailable");
    this.name = "LifePlacementSceneUnavailableError";
  }
}

export type LifePlacementSceneSource = {
  readonly map: GameMap;
  readonly session: PlaySession;
  readonly tileX: number;
  readonly tileY: number;
  readonly facing: Dir;
  readonly eventPositions: RuntimeEventPositions;
};

export function isUsableLiveActor(actor: SpatialLiveActor): boolean {
  return actor.mapId.length > 0
    && Number.isSafeInteger(actor.x)
    && Number.isSafeInteger(actor.y)
    && Number.isSafeInteger(actor.footprint.width)
    && Number.isSafeInteger(actor.footprint.height);
}

/**
 * Discrete live bodies for placement. Player uses the committed foot tile (origin while a
 * step is in flight). NPCs use runtimeEventView coordinates (destination at step start).
 * Page-less, erased, off-map, below, and pass-through events are not walking walls.
 */
export function readLifePlacementLiveContext(
  project: Project,
  scene: LifePlacementSceneSource,
): SpatialLiveContext | undefined {
  if (!scene.map || !Number.isSafeInteger(scene.tileX) || !Number.isSafeInteger(scene.tileY)) return undefined;
  const body = resolvePlayerBody(project, scene.session);
  const player: SpatialLiveActor = {
    mapId: scene.map.id,
    x: scene.tileX,
    y: scene.tileY,
    footprint: body.footprint,
    passRows: body.passRows,
  };
  if (!isUsableLiveActor(player)) return undefined;
  const npcs: SpatialLiveActor[] = [];
  for (const view of runtimeEventViewsForMap(project, scene.map, scene.session, scene.eventPositions)) {
    if (!view.page) continue;
    if (view.priority !== "same" || !view.overlapForbidden) continue;
    if (!Number.isSafeInteger(view.x) || !Number.isSafeInteger(view.y)) continue;
    const actor: SpatialLiveActor = {
      mapId: scene.map.id,
      x: view.x,
      y: view.y,
      footprint: view.footprint,
      passRows: view.passRows,
    };
    if (isUsableLiveActor(actor)) npcs.push(actor);
  }
  return { player, npcs };
}

export function createLifePlacementLiveReader(
  getScene: () => LifePlacementSceneSource | undefined,
  getProject: () => Project,
): SpatialLiveContextReader {
  return () => {
    const scene = getScene();
    if (!scene) throw new LifePlacementSceneUnavailableError();
    const live = readLifePlacementLiveContext(getProject(), scene);
    if (!live) throw new LifePlacementSceneUnavailableError();
    return live;
  };
}
