import subprocess, pathlib, json, hashlib, os
E = pathlib.Path(__file__).resolve().parent
P = pathlib.Path('/home/main/z-project/rpg-zzu-life-full-spatial-rights')
def run(name, args):
    (E / (name+'.command.json')).write_text(json.dumps(args)+'\n')
    r = subprocess.run(args, cwd=P, capture_output=True, timeout=60)
    (E / (name+'.stdout')).write_bytes(r.stdout)
    (E / (name+'.stderr')).write_bytes(r.stderr)
    (E / (name+'.exit')).write_text(str(r.returncode)+'\n')
    return r
run('identity-before', ['git','show','--no-patch','--format=fuller','HEAD'])
run('status-before', ['git','status','--porcelain=v1','--untracked-files=all'])
run('base-diff', ['git','diff','--exit-code','b5c679efc6c5e575f7a1afb65dfa86939aade325','HEAD','--','src','test','scripts','package.json','vitest.config.ts'])
run('working-diff', ['git','diff','--exit-code','HEAD'])
paths=['src/project/lifeRecovery.ts','src/project/spatialPlacementTransactions.ts','src/project/spatialPlacements.ts','src/project/types/database.ts','test/spatialPaymentReceipts.test.ts','test/lifeRecoveryPersistence.test.ts']
manifest={}
for p in paths:
    data=(P/p).read_bytes()
    manifest[p]=hashlib.sha256(data).hexdigest()
    (E/('source-'+p.replace('/','__'))).write_bytes(data)
(E/'source-sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
for label, p in [('producer-summary',P/'.omo/evidence/life-full-20260906/47-48/SUMMARY.md'),('canonical-plan',pathlib.Path('/home/main/.herdr/worktrees/rpg-zzu/wish-html/.omo/plans/life-systems-full-implementation.md'))]:
    (E/(label+'.txt')).write_bytes(p.read_bytes())
parent=pathlib.Path('/home/main/z-project/rpg-zzu-life-full-p4/.omo/evidence/life-full-20260906/placement-parent-astra')
for f in ['VERIFY.md','recovery-rights.stderr','recovery-rights.exit']:
    (E/('historical-parent-'+f)).write_bytes((parent/f).read_bytes())
run('identity-after', ['git','show','--no-patch','--format=fuller','HEAD'])
run('status-after', ['git','status','--porcelain=v1','--untracked-files=all'])
run('working-diff-after', ['git','diff','--exit-code','HEAD'])
unchanged=all(hashlib.sha256((P/p).read_bytes()).hexdigest()==h for p,h in manifest.items())
(E/'cleanup.json').write_text(json.dumps({'sourceHashesUnchanged':unchanged,'headUnchanged':(E/'identity-before.stdout').read_bytes()==(E/'identity-after.stdout').read_bytes(),'verificationWorktreeCreated':False,'reason':'No correction commit; explicit blocker-first branch. Destination is evidence-only, not an adopted checkout.','ownedScratchCachesServersDependencies':[], 'retained':'Evidence directory and wrapper only','sharedCleanup':False,'model':os.environ.get('PI_MODEL'),'provider':os.environ.get('PI_PROVIDER')},indent=2)+'\n')
assert unchanged
