timeout --kill-after=15s 1020s flock --timeout 900 /tmp/rpg-zzu-life-full-qa-01a0727b.lock python3 capture.py
