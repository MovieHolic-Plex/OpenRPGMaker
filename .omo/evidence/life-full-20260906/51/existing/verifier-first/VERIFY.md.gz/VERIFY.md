# Plan47/48 independent Astra verification: NEEDS-FIX / BLOCKED

## Outcome

There is no committed correction to verify. Independently inspected producer SUMMARY.md explicitly says "blocked before implementation" and "No correction or implementation commit was made." Actual producer HEAD before and after this inspection is `b5c679efc6c5e575f7a1afb65dfa86939aade325`, the original failing integrated base. Base-to-HEAD scoped diff and whole tracked working-tree diff both exit0. This is a failed entry criterion, not confirmation of either correction, task12, Phase4, or the whole goal.

The explicit instruction to report a blocker/no-new-commit instead of verifying base b5c679ef controls this outcome. No detached verification checkout was created or canonically adopted at that base. The requested destination contains evidence only, not a Git worktree; no misleading locked/adopted checkout claim is made. Sparse population, dependency provisioning and private cache setup were therefore not entered.

## Exact unmet criteria

- **Entry criterion:** a new committed plan47/48 implementation must exist. It does not.
- **47:** after a real gold10+item1 payment, incompatibility, item collection and Save5 resume, retain unpaid gold10 proof without automatic gold credit and remove the collected claim ID; split claims must not multiply rights, and legacy mixed evidence must not be speculatively grouped. No new implementation or baseline GREEN / behavioral RED / final GREEN exists for this criterion. The actual historical parent stderr was read: exit1, `PROVED-RIGHTS GAP: collecting building items deletes its unresolved receipt including unpaid gold10`. That is historical evidence, not a rerun here.
- **48:** freeze actual new decoration payment/recovery proof across changed/deleted definitions/items, ordinary reclaim, quarantine/collect, repeated Save5 and unknown/restored items; distinguish genuinely free new placements from missing-proof legacy without inferring old costs. Producer reports the free-placement contract unresolved: existing public placement requires a known placementItemId and consumes one item; authored starting placements lack proof. Producer recommends an explicitly approved starting-placement proof rule. This report records that blocker, not a new policy decision.

Actual source inspection corroborates unchanged owners: `spatialPlacementTransactions.ts` creates decoration placement via `placementFields(input)` while consuming placementItemId, and ordinary removal reads the current type's item ID. `lifeRecovery.ts` derives building recovery items from receipt.items and collects by removing the claim. The existing H1/H2 test source was read: H2 uses gold0 and expects claims to become empty after collection, so that assertion cannot establish preservation of unpaid gold10. Source snapshots and SHA256 are retained; no tests were edited.

## Commands and evidence

`capture.py` is an evidence-only wrapper. `capture.command`, `capture.stdout`, `capture.stderr`, `capture.exit` retain the real bounded execution under shared `flock --timeout 900 /tmp/rpg-zzu-life-full-qa-01a0727b.lock`; direct wrapper exit0. Every child Git command has exact `.command.json`, direct `.stdout`, `.stderr`, and `.exit`. Identity, status, base diff and working diff commands all exit0. Before/after status output is empty. Source hashes and HEAD match before/after (`cleanup.json`). Runtime identity is gpt-6-astra / opencodex.

`producer-summary.txt`, `canonical-plan.txt`, historical parent VERIFY and actual failure stderr/exit preserve inputs. `source-*` files preserve the inspected current production/test files, not edited copies. Canonical plan47/48 and the original parent's VERIFY and raw failure were actually read. Parent build output was not read or rerun in this blocked branch; its build is not claimed verified here.

## Unexecuted verification, scope audit and cleanup

No focused tests, diagnostics, typecheck, build, independent-rights.mts or Vite-node import-resolution probe were run. There is no producer correction-focused command or baseline/RED/final evidence to rerun/trust. Full parser/whitelist/normalizer/reconcile audit, capacity/sequence/inventory/malformed whole-session and prior-slot checks, H1/H2/housing limits, no-refund demolition, Project4/Save4-to5 and no-context-persistence constraints remain unverified for a correction. Unexecuted is not pass.

Dirty/stale source and misleading success were checked: tracked source is unchanged, source identity is the failing base, historical exit1 is explicitly labeled, and setup/inspection exit0 is not behavioral GREEN. No observed setup error in the captured wrapper. No tests removed, weakened or skipped; no repeated validator, broad suite, deadline/config change, cache duplication, product/test/config edit, install, remote operation, commit, merge or push. No UI/browser/scene/render/image work and no CLAUDE.md read. Mixed lifeFieldInteraction and all native UI remain Grok-owned and unverified here; no Grok completion inferred.

Cleanup receipt records no owned processes, servers, temporary caches, dependencies or scratch resources. No shared cleanup occurred. Only the requested evidence directory and its wrapper/snapshots remain. Verification is blocked pending a committed correction and resolution of the reported free/legacy contract; neither registered correction is approved.
