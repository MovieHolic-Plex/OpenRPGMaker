df -h / /dev/shm 
