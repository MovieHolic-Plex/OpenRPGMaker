git -C /home/main/z-project/rpg-zzu-life-full-spatial-rights rev-parse HEAD 
