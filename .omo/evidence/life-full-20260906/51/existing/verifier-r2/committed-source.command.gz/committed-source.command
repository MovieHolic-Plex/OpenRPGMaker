git -C /home/main/z-project/rpg-zzu-life-full-spatial-rights show HEAD:src/project/lifeRecovery.ts 
