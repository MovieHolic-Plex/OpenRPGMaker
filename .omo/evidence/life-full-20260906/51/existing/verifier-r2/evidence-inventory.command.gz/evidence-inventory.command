find /home/main/z-project/rpg-zzu-life-full-spatial-rights/.omo/evidence/life-full-20260906/47-48 -maxdepth 3 -type f 
