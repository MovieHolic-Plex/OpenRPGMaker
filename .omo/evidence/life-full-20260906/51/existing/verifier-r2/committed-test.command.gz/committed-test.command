git -C /home/main/z-project/rpg-zzu-life-full-spatial-rights ls-tree HEAD test/spatialRecoveryRights.test.ts 
