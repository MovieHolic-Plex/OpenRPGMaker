# Plan47/48 r2 journal

Worktree reused at b5c679efc6c5e575f7a1afb65dfa86939aade325; clean initial git status. PI_MODEL=gpt-6-astra, PI_PROVIDER=opencodex. Disk checked before creation: 2.4G available on /dev/sda2; /dev/shm has 49G available. No installation.

Setup commands (exit0): git read-tree -mu HEAD; npm run wt -- adopt life-full-spatial-rights --path /home/main/z-project/rpg-zzu-life-full-spatial-rights (already configured, port9841). Existing sparse selection includes full src/test/scripts/openwiki/public/vendor and root configs. No reset/recreation. First-attempt evidence is untouched.

Hypotheses: (1) collection destroys mixed unpaid evidence; (2) decoration producer omits proof; (3) save parser/reconciliation could independently discard proof. Parent raw data confirms (1)/(2); source tracing identifies parser/reconciliation boundaries for (3). New independent RED assertions must exercise both gaps, not reuse the stopped parent assertion as decoration coverage.

Owned artifacts: this r2 directory, focused test file, scoped product/wiki edits, private /dev/shm scratch with TMPDIR/cache/dist symlink during validators. Original parent probe/failure and first attempt remain read-only. No servers or remote writes planned.
