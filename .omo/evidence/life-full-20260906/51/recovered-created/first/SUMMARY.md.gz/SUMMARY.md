# Plan47/48 - blocked before implementation

## Outcome

No correction or implementation commit was made. The source is unchanged at
`b5c679efc6c5e575f7a1afb65dfa86939aade325` on `agent/life-full-spatial-rights`.
Task12, independent verification, Grok wiring and the full goal remain pending.

Concrete recovery-contract ambiguity: the requested **new free decoration placement**
has no existing public creation path. `HomeDecorationTypeRecord.placementItemId` is
required (`src/project/types/database.ts:886`); normalization rejects a missing ID
(`src/project/spatialPlacements.ts:101-103`); `placeHomeDecoration` requires a known
item and consumes exactly one (`src/project/spatialPlacementTransactions.ts:126-129`).
Authored starting placements are cloned without evidence (`src/project/session.ts:481-487`),
so treating those as newly proved free placements would conflate them with legacy
missing-proof placements. No schema or historical-rights policy was silently changed.

**Caller decision needed:** does "new free" mean a new-session authored starting
placement (which would need an explicit approved proof rule), or a new runtime
free-placement feature? The latter requires scope expansion into the authored
schema/normalization contract. Recommendation: define the starting-placement proof
rule explicitly rather than inventing an optional-cost placement feature in this fix.
The two paid-asset gaps remain proved by the parent's evidence; this blocker does
not dispute them. No partial product fix was shipped because the requested unit is
one cohesive correction and the free/legacy proof boundary affects its schema.

## Setup and source receipts

- Worktree: `/home/main/z-project/rpg-zzu-life-full-spatial-rights`.
- Runtime identity: `PI_MODEL=gpt-6-astra`, `PI_PROVIDER=opencodex`; `state.txt`.
- Disk checked before creation: `/dev/sda2`, 914G size, 873G used, 2.8G available,
  rounded utilization 100%. Post-adoption disk and tmpfs are in `state.txt`.
- Creation command, direct exit0:
  `git -C /home/main/z-project/rpg-zzu-life-full-p4 worktree add --no-checkout -b agent/life-full-spatial-rights /home/main/z-project/rpg-zzu-life-full-spatial-rights b5c679efc6c5e575f7a1afb65dfa86939aade325`
- Sparse population commands, direct exit0:
  `git -C /home/main/z-project/rpg-zzu-life-full-spatial-rights sparse-checkout set src test scripts openwiki public vendor`
  then `git -C /home/main/z-project/rpg-zzu-life-full-spatial-rights read-tree -mu HEAD`.
  All root configuration files and full selected directories were populated before
  source existence claims. No install was performed.
- Adoption command from THIS tree:
  `npm run wt -- adopt life-full-spatial-rights --path /home/main/z-project/rpg-zzu-life-full-spatial-rights`.
  Direct exit0 in `adopt.exit`; complete `adopt.stdout` and `adopt.stderr` retained.
  Shared dependency symlink and local env provisioned, reported port9841. No server
  launched and no port availability/uniqueness claim beyond the adoption output.
- `source-blocker.txt`: exact line-numbered current owners, produced with `rg`.
- `git diff --exit-code HEAD -- src test scripts openwiki`: exit0 (`state.txt`).
- Canonical AGENTS, quickstart, INDEX, PROJECT_WIKI and worktree instructions read;
  parent's EXECUTED_PLAN recovery policy/47/48 and placement-parent-astra VERIFY,
  actual failure script, raw failure and relevant raw paid-state section read.
  Programming/debugging skill entry points read; implementation-stage references
  and runtime debugging were not entered. Every CLAUDE.md was ignored.
- `parent-receipt.txt`: parent's current status and SHA256 of its original VERIFY,
  probe, state and raw failure files. No writes were issued into the parent tree.
  These are end-state hashes, not a fabricated before/after comparison.

## Verification and limits

No characterization GREEN, new behavioral RED, final focused test run, diagnostics,
app typecheck, build or public MemoryStorage probe was run. Therefore there is no
new behavioral success/failure receipt and no verified implementation SHA. Parent
224/14 results are historical only, not counted as this task's verification.
The parent's original probe stops at its gold assertion; it is not claimed to be a
separate decoration RED. `lifeFieldInteraction.test.ts` was not run.

Setup errors are separate from product failures: initial exploratory skill/path
lookups returned missing-path/nonmatch exits; the broad worktree listing was
truncated with the tool retaining its archive. Adoption and population succeeded.
`command -v apply_patch` returns1 in this environment (`cleanup.txt`); no alternative
patch mechanism was used to modify product files. Evidence-only new files were
written through the provided file/shell tools.

Adversarial verification classes: stale/dirty source was checked with exact HEAD
and source diff; misleading output was avoided by retaining adoption's direct
exit separately. Malformed recovery, long validator command and interruption
behavior remain **unexecuted**, not passes. UI/browser/image/renderer classes are
N/A by scope. No heavy command was launched, so no flock, timeout, private build
cache or validator cleanup was required. No tests were weakened/skipped/deleted.

## Exact new path list and cleanup

All deliverable files are untracked evidence under
`.omo/evidence/life-full-20260906/47-48/`:

- `SUMMARY.md`
- `adopt.stdout`
- `adopt.stderr`
- `adopt.exit`
- `state.txt`
- `source-blocker.txt`
- `parent-receipt.txt`
- `cleanup.txt`

No source/test/wiki/config edits. Adoption also created the ignored local
`node_modules` symlink and `.env.local` (not deliverable content; no credentials
recorded). Worktree and provisioned environment are retained for the coordinator,
not removed because this named path is the verifier handoff. No processes,
private TMPDIR/cache/dist, browser, remote writes, merge/push/PR or commit to clean.
`cleanup.txt` records resource state. Final commit SHA: **none (blocked)**.
