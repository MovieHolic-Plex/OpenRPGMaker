#!/usr/bin/env bash
set -eu
cd /home/main/z-project/rpg-zzu-life-full-spatial-rights
E="$PWD/.omo/evidence/life-full-20260906/47-48/r2"
S=$(mktemp -d /dev/shm/st_01a07972-final.XXXXXX)
export TMPDIR="$S/tmp" VITE_CACHE_DIR="$S/cache"
mkdir -p "$TMPDIR" "$VITE_CACHE_DIR" "$S/dist"
printf '%s\n' "$S" > "$E/scratch-path.txt"
test ! -e dist && test ! -L dist
ln -s "$S/dist" dist
cleanup() {
  du -sh "$S" > "$E/cleanup-size.txt"
  if [ "$(readlink dist)" = "$S/dist" ]; then unlink dist; fi
  rm -rf "$S"
  printf '{"ownedScratchRemoved":true,"ownedDistRemoved":true,"serversStarted":false,"sharedCachesDeleted":false}\n' > "$E/cleanup.json"
}
trap cleanup EXIT
run() {
  name=$1; seconds=$2; shift 2
  sha256sum --quiet -c "$E/final-source.sha256" || exit 91
  printf 'flock --timeout 900 /tmp/rpg-zzu-life-full-qa-01a0727b.lock timeout --kill-after=15s %ss ' "$seconds" >> "$E/commands.txt"
  printf '%q ' "$@" >> "$E/commands.txt"; printf '\n' >> "$E/commands.txt"
  set +e
  flock --timeout 900 /tmp/rpg-zzu-life-full-qa-01a0727b.lock timeout --kill-after=15s "${seconds}s" "$@" > "$E/$name.stdout" 2> "$E/$name.stderr"
  code=$?
  set -e
  printf '%s\n' "$code" > "$E/$name.exit"
  printf '%s exit=%s\n' "$name" "$code"
  sha256sum --quiet -c "$E/final-source.sha256" || exit 91
  test "$code" = 0
}
run diagnostics 360 node "$E/diagnostics.mjs"
run tests 420 node scripts/run-vitest.mjs run --configLoader runner --cache=false test/lifePlacementSafety.test.ts test/p2SpatialTransactions.test.ts test/p2SpatialPersistence.test.ts test/p2SpatialSchema.test.ts test/p2SpatialReferenceIntegrity.test.ts test/linkedAnimalHousing.test.ts test/spatialPaymentReceipts.test.ts test/lifeRecoveryPersistence.test.ts test/seasonalForage.test.ts test/toolActionAuthoringParity.test.ts test/p2LifeRuntime.test.ts test/p2HostileAudit.test.ts test/lifeSkillDisabledHarvest.test.ts test/p2SessionPersistence.test.ts test/lifeRecovery.test.ts test/lifeRecoveryRecordKeys.test.ts test/lifeSaveVersion.test.ts test/spatialRecoveryRights.test.ts --maxWorkers=2 --minWorkers=1
run public-rights 360 node node_modules/vite-node/vite-node.mjs --config vitest.config.ts "$E/public-rights.mts"
run typecheck 360 npm run typecheck:app
run build 900 npm run build
run diff-check 60 git diff --check
