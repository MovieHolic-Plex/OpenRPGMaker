# 런타임 QA — event-command-remediation-u05-edges

**이 파일을 먼저 읽어라.** PNG 는 아래 표에서 "즉시 확인" 으로 표시된 것만 열어라.
전량 열람은 컨텍스트 낭비다.

- 시각 검토: 별도 판정 필요 — 실행 비트 통과는 공간 구성·물체 식별·게임 경험의 합격을 뜻하지 않습니다.
- 게이트: 실패 (비트 2개 중 2개 실패)
- 열어야 할 샷: 2개 / 전체 샷 2개
- 런타임 에러 54건
- 프로젝트: ../../../../../../tmp/event-command-u05-2dCkLZ/fixtures/player-edges.json
- 시드: 1 / 뷰포트: 1024×768

| 비트 | 의도 | 상태 | 샷 | 볼 이유 |
|---|---|---|---|---|
| boot | — | 실패 | 01-boot.png | 게이트 실패 — 즉시 확인 |
| execute | Real action key executes authored commands in dedicated player.html; untargeted values distinguish party mistakes. | 실패 | 02-execute.png | 게이트 실패 — 즉시 확인 |

## 실패 상세

### boot
- op eventCommand 실패: page.evaluate: Execution context was destroyed, most likely because of a navigation

### execute
- op face 실패: page.waitForFunction: Timeout 120000ms exceeded.

## 런타임 에러

- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: [player] failed to start play game: TypeError: Failed to fetch dynamically imported module: http://127.0.0.1:36135/src/player/PlayScene.ts?t=1788702928193`
- `console: [play-boot] [play-boot] stage=error fail map=map_u05 stale-module-reload err=Failed to fetch dynamically imported module: http://127.0.0.1:36135/src/player/PlayScene.ts?t=1788702928193 {kind: play-boot, stage: error, ok: false, mapId: map_u05, elapsedMs: 912}`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`
- `console: Failed to load resource: net::ERR_NETWORK_CHANGED`

