# 런타임 QA — event-command-remediation-u07-map

**이 파일을 먼저 읽어라.** PNG 는 아래 표에서 "즉시 확인" 으로 표시된 것만 열어라.
전량 열람은 컨텍스트 낭비다.

- 시각 검토: 별도 판정 필요 — 실행 비트 통과는 공간 구성·물체 식별·게임 경험의 합격을 뜻하지 않습니다.
- 게이트: 실패 (비트 2개 중 1개 실패)
- 열어야 할 샷: 1개 / 전체 샷 1개
- 런타임 에러: 없음
- 프로젝트: .omo/evidence/event-command-remediation/U07/surface-utyQuE/tmp-player-wcbhvo/map.json
- 시드: 1 / 뷰포트: 1280×800

| 비트 | 의도 | 상태 | 샷 | 볼 이유 |
|---|---|---|---|---|
| boot | — | 통과 | — | — |
| g2-f9-g3-f22-g3-f24-g4-f11-g4-f13 | — | 실패 | 02-g2-f9-g3-f22-g3-f24-g4-f11-g4-f13.png | 게이트 실패 — 즉시 확인 |

## 실패 상세

### g2-f9-g3-f22-g3-f24-g4-f11-g4-f13
- playerSprite: 텍스처가 로드되지 않았다(__MISSING) — resourceId=u07-charset-new

