import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { editorState } from "@/editor/editorState";
import { newM2Command } from "@/editor/eventCommandFactory";
import { replaceEventPageCommandAt } from "@/editor/eventPages";
import { validateEventDraft } from "@/editor/eventDraftValidator";
import { openEventCommandEditDialog } from "@/editor/panels/eventEditor/commandEditDialog";
import { resetModalStackForTest } from "@/editor/ui/modalStack";
import { createInterpreter } from "@/player/interpreter";
import { runCommands } from "@/player/playSceneInterpreter";
import { applySaveSnapshot, createSaveSnapshot } from "@/player/saveSlots";
import { findBlockingRuntimeEventAtInMap, findRuntimeEventAtInMap, runtimeEventViewsForMap } from "@/project/runtimeEventState";
import { deserialize, serialize } from "@/project/io";
import { store } from "@/project/store";
import type { Command } from "@/project/types";
import { installFakeDom } from "../fakeDom";
import { AWAY, buildFixture, COMMON, HOME, HOST, LIBRARY, m2, OTHER, PAGE, runtimeFixture, SELECTED, spawn, SPAWN, storedCommand, TEMPLATE, UNKNOWN, type M2Command } from "./U10.fixture";

let restoreDom: () => void;
let project: ReturnType<typeof buildFixture>;

beforeEach(() => {
  restoreDom = installFakeDom({ animationFrames: "manual" });
  resetModalStackForTest();
  project = buildFixture();
  store.replace(project, { preserveEventDrafts: false });
  editorState.set({ currentMapId: HOME, selectedEventId: HOST, selectedEventPageId: PAGE });
});

afterEach(() => {
  document.querySelector<HTMLElement>('[data-testid="event-command-edit-cancel"]')?.click();
  document.body.replaceChildren();
  resetModalStackForTest();
  vi.restoreAllMocks();
  restoreDom();
});

function control<T extends HTMLElement = HTMLElement>(id: string): T {
  const element = document.querySelector<T>(`[data-testid="${id}"]`);
  if (!element) throw new Error(`Missing rendered U10 control: ${id}`);
  return element;
}

function open(initial: M2Command) {
  const apply = vi.fn((command: Command) => replaceEventPageCommandAt(HOME, HOST, PAGE, [0], command));
  openEventCommandEditDialog({ initial, onApply: apply });
  // A missing intended control is RED only after the real body has rendered.
  expect(control(`m2-command-body-${initial.commandId}`)).toBeTruthy();
  return apply;
}

function field(key: string): HTMLInputElement | HTMLSelectElement {
  const body = control("event-command-edit-form");
  const element = Array.from(body.querySelectorAll<HTMLInputElement | HTMLSelectElement>("input, select"))
    .find(element => element.dataset.testid?.startsWith(`m2-command-${key}-`));
  if (!element) throw new Error(`No rendered control for existing M2 field ${key}`);
  return element;
}

function change(element: HTMLInputElement | HTMLSelectElement, value: string): void {
  // fakeDom does not enforce native select values: never inject a nonexistent option.
  if (element.tagName === "SELECT") {
    expect(Array.from(element.querySelectorAll("option")).map(option => option.value)).toContain(value);
  }
  element.value = value;
  element.dispatchEvent(new Event("change", { bubbles: true }));
}

function confirm(): M2Command {
  control("event-command-edit-ok").click();
  return storedCommand(store.getCurrent());
}

function execute(command: Command, runtime: ReturnType<typeof runtimeFixture>, currentEventId?: string) {
  const interpreter = createInterpreter([command], runtime.session, project, { currentEventId });
  const result = interpreter.start();
  // Each fixture contains only a single nonwaiting command; no polling/drain loop.
  if (result.kind !== "done") expect(interpreter.resume(undefined)).toEqual({ kind: "done" });
  return result;
}

function validate(command: M2Command) {
  const copy = structuredClone(project);
  copy.maps[HOME]!.events.find(event => event.id === HOST)!.pages![0]!.commands = [command];
  return validateEventDraft(copy, HOME, HOST);
}

function identityState(runtime: ReturnType<typeof runtimeFixture>) {
  return structuredClone({
    locations: runtime.session.eventLocations ?? {},
    spawned: runtime.session.spawnedEvents ?? {},
    removed: runtime.session.removedEventIds ?? {},
    runtimeEvents: runtime.session.m2Runtime?.events ?? {},
    home: runtime.views(HOME), away: runtime.views(AWAY), library: runtime.views(LIBRARY),
  });
}

describe("U10/G1-F1 selected Erase Event", () => {
  it("PASS control: stages selection, Confirm/reload preserves it, reopened Cancel isolates edits", () => {
    const initial = storedCommand(project);
    const apply = open(initial);
    change(control<HTMLSelectElement>("m2-erase-event-target"), SELECTED);
    expect(apply).not.toHaveBeenCalled();
    expect(storedCommand(store.getCurrent())).toEqual(initial);
    const saved = confirm();
    expect(apply).toHaveBeenCalledExactlyOnceWith(saved);
    expect(saved.fields.eventId).toBe(SELECTED);
    expect(storedCommand(deserialize(serialize(store.getCurrent())))).toEqual(saved);
    const reopenApply = open(saved);
    expect(control<HTMLSelectElement>("m2-erase-event-target").value).toBe(SELECTED);
    change(control<HTMLSelectElement>("m2-erase-event-target"), HOST);
    control("event-command-edit-cancel").click();
    expect(reopenApply).not.toHaveBeenCalled();
    expect(storedCommand(store.getCurrent())).toEqual(saved);
  });

  it("RED: confirmed selectedOther hides only selectedOther through the actual scene consumer", async () => {
    open(m2("Erase Event"));
    change(control<HTMLSelectElement>("m2-erase-event-target"), SELECTED);
    const saved = confirm();
    expect(saved.fields.eventId).toBe(SELECTED);
    const runtime = runtimeFixture(project);
    await runCommands(runtime.scene, [saved], HOST);
    expect.soft(runtime.views().map(view => view.event.id)).toContain(HOST);
    expect.soft(runtime.views().map(view => view.event.id)).not.toContain(SELECTED);
    expect.soft([...runtime.destroyed]).toEqual([SELECTED]);
    expect.soft(runtime.sprites.has(HOST)).toBe(true);
    expect(runtime.session.removedEventIds).toEqual({});
  });

  it.each([HOST, undefined])("RED: selected target survives common-event execution with host=%s", async host => {
    project.commonEvents[0]!.commands = [m2("Erase Event", { eventId: SELECTED })];
    store.replace(project);
    const runtime = runtimeFixture(project);
    await runCommands(runtime.scene, [{ kind: "callCommonEvent", commonEventId: COMMON }], host);
    expect.soft(runtime.views().map(view => view.event.id)).toContain(HOST);
    expect.soft(runtime.views().map(view => view.event.id)).not.toContain(SELECTED);
    expect.soft([...runtime.destroyed]).toEqual([SELECTED]);
  });

  it("PASS control: deliberately choosing the existing current-event option erases only the host", async () => {
    open(m2("Erase Event", { eventId: SELECTED }));
    // The existing Erase form encodes its explicitly chosen current-event option as empty.
    change(control<HTMLSelectElement>("m2-erase-event-target"), "");
    const saved = confirm();
    const runtime = runtimeFixture(project);
    await runCommands(runtime.scene, [saved], HOST);
    expect(runtime.views().map(view => view.event.id)).toEqual([SELECTED]);
    expect([...runtime.destroyed]).toEqual([HOST]);
    expect(runtime.session.removedEventIds).toEqual({});
  });

  it("PASS control: standalone current-event without a host cannot erase another event", async () => {
    const runtime = runtimeFixture(project);
    await runCommands(runtime.scene, [m2("Erase Event", { eventId: "" })]);
    expect(runtime.views().map(view => view.event.id)).toEqual([HOST, SELECTED]);
    expect([...runtime.destroyed]).toEqual([]);
  });

  it("RED: unknown selected ID is preserved on edit and must not fall back to the host", async () => {
    open(m2("Erase Event", { eventId: UNKNOWN }));
    expect(control<HTMLSelectElement>("m2-erase-event-target").value).toBe(UNKNOWN);
    const saved = confirm();
    expect(saved.fields.eventId).toBe(UNKNOWN);
    const runtime = runtimeFixture(project);
    await runCommands(runtime.scene, [saved], HOST);
    expect.soft(runtime.views().map(view => view.event.id)).toEqual([HOST, SELECTED]);
    expect.soft([...runtime.destroyed]).toEqual([]);
  });
});

describe("U10/G3-F19 Spawn Event identity", () => {
  it("RED: rendered new instance control accepts an ID rather than choosing an authored event", () => {
    const apply = open(spawn());
    const instance = field("eventId");
    expect(instance.tagName).toBe("INPUT");
    change(instance, "spawnB");
    change(field("x"), "6");
    expect(apply).not.toHaveBeenCalled();
    expect(confirm().fields).toMatchObject({ prefabId: TEMPLATE, eventId: "spawnB", x: 6, y: 3 });
  });

  it("RED: template has a picker distinct from the new instance input", () => {
    open(spawn());
    const template = field("prefabId");
    expect(template).not.toBe(field("eventId"));
    expect(template.tagName).toBe("SELECT");
    change(template, TEMPLATE);
    expect(confirm().fields).toMatchObject({ prefabId: TEMPLATE, eventId: SPAWN });
  });

  it("RED: new-command default ID is nonempty, deterministic, unused, and retained by Confirm", () => {
    const commandId = spawn().commandId;
    const first = newM2Command(commandId);
    const second = newM2Command(commandId);
    expect(first.fields.eventId).toBe(second.fields.eventId);
    open({ ...first, fields: { ...first.fields, prefabId: TEMPLATE } });
    const saved = confirm();
    const id = String(saved.fields.eventId ?? "");
    expect(id.trim().length).toBeGreaterThan(0);
    expect(Object.values(project.maps).flatMap(map => map.events.map(event => event.id))).not.toContain(id);
  });

  it("RED: blank runtime instance ID resolves to a nonempty unused identity, including the emitted step", () => {
    const runtime = runtimeFixture(project);
    execute(spawn(`${TEMPLATE}_spawn`), runtime, HOST);
    const prior = identityState(runtime);
    const result = execute(spawn(""), runtime, HOST);
    const added = Object.keys(runtime.session.spawnedEvents ?? {}).filter(id => !(id in prior.spawned));
    expect(added).toHaveLength(1);
    expect.soft(added[0]!.trim().length).toBeGreaterThan(0);
    expect.soft(result).toEqual({ kind: "spawnEvent", eventId: added[0] });
    expect.soft(runtime.session.spawnedEvents?.[`${TEMPLATE}_spawn`]).toEqual(prior.spawned[`${TEMPLATE}_spawn`]);
  });

  it.each([HOST, TEMPLATE, OTHER])("RED: authored collision %s cannot mutate or relocate any existing identity", id => {
    const runtime = runtimeFixture(project);
    const before = identityState(runtime);
    execute(spawn(id, AWAY, 8, 6), runtime, HOST);
    expect(identityState(runtime)).toEqual(before);
  });

  it("RED: runtime collision cannot overwrite a previously spawned instance or location", () => {
    const runtime = runtimeFixture(project);
    execute(spawn(), runtime, HOST);
    const before = identityState(runtime);
    execute(spawn(SPAWN, AWAY, 8, 6), runtime, HOST);
    expect(identityState(runtime)).toEqual(before);
  });

  it("RED: authored collision is rejected by draft validation, unlike a fresh instance ID", () => {
    expect(validate(spawn()).canCommit).toBe(true);
    expect(validate(spawn(HOST)).canCommit).toBe(false);
  });

  it("PASS control: distinct clones retain template graphics, blocking and trigger commands without moving template", () => {
    const runtime = runtimeFixture(project);
    const beforeTemplate = runtime.views(LIBRARY);
    expect(execute(spawn(), runtime, HOST)).toEqual({ kind: "spawnEvent", eventId: SPAWN });
    execute(spawn("spawnB", AWAY, 6, 4), runtime, HOST);
    const view = runtime.views().find(view => view.event.id === SPAWN)!;
    expect(view).toMatchObject({ x: 4, y: 3, priority: "same", trigger: { kind: "action" } });
    expect(view.sprite).toEqual(beforeTemplate[0]!.sprite);
    expect(findBlockingRuntimeEventAtInMap(project, project.maps[HOME]!, runtime.session, runtime.positions, 4, 3)?.event.id).toBe(SPAWN);
    const target = findRuntimeEventAtInMap(project, project.maps[HOME]!, runtime.session, runtime.positions, 4, 3, "action");
    expect(target?.event.id).toBe(SPAWN);
    expect(createInterpreter(target!.page!.commands, runtime.session, project, { currentEventId: SPAWN }).start()).toEqual({ kind: "done" });
    expect(runtime.session.switches.spawnTriggered).toBe(true);
    expect(runtime.views(AWAY).find(view => view.event.id === "spawnB")).toMatchObject({ x: 6, y: 4 });
    expect(runtime.views(LIBRARY)).toEqual(beforeTemplate);
    expect(runtime.session.eventLocations?.[TEMPLATE]).toBeUndefined();
  });
});

describe("U10/G3-F20 Remove Event identity and owning map", () => {
  it("RED: rendered target can accept a spawned ID not in authored event records", () => {
    project.maps[HOME]!.events[0]!.pages![0]!.commands = [spawn(), m2("Remove Event")];
    store.replace(project);
    open(m2("Remove Event"));
    const target = field("eventId");
    const available = target.tagName === "INPUT" || Array.from(target.querySelectorAll("option")).some(option => option.value === SPAWN);
    expect(available).toBe(true);
    change(target, SPAWN);
    expect(confirm().fields.eventId).toBe(SPAWN);
  });

  it("PASS control: unknown authored ID survives Confirm/reopen/Cancel and serialization", () => {
    const apply = open(m2("Remove Event", { eventId: UNKNOWN }));
    expect(field("eventId").value).toBe(UNKNOWN);
    const saved = confirm();
    expect(apply).toHaveBeenCalledExactlyOnceWith(saved);
    expect(saved.fields.eventId).toBe(UNKNOWN);
    expect(storedCommand(deserialize(serialize(store.getCurrent())))).toEqual(saved);
    const canceled = open(saved);
    change(field("eventId"), HOST);
    control("event-command-edit-cancel").click();
    expect(canceled).not.toHaveBeenCalled();
    expect(storedCommand(store.getCurrent())).toEqual(saved);
  });

  it("RED: unknown target is diagnosable by draft validation without rewriting its ID", () => {
    const command = m2("Remove Event", { eventId: UNKNOWN });
    const validation = validate(command);
    expect(validation.issues.some(issue => issue.commandPath?.[0] === 0 && ["warning", "error"].includes(issue.severity))).toBe(true);
    expect(command.fields.eventId).toBe(UNKNOWN);
  });

  it("RED: choosing an authored event on another map removes it on its owner map and survives save/load", () => {
    open(m2("Remove Event"));
    change(field("eventId"), OTHER);
    const saved = confirm();
    expect(saved.fields.eventId).toBe(OTHER);
    const runtime = runtimeFixture(project);
    execute(saved, runtime, HOST);
    expect.soft(runtime.views(AWAY).map(view => view.event.id)).not.toContain(OTHER);
    expect.soft(runtime.session.removedEventIds?.[AWAY]).toContain(OTHER);
    expect.soft(runtime.session.removedEventIds?.[HOME] ?? []).not.toContain(OTHER);
    const restored = applySaveSnapshot(project, createSaveSnapshot(project, runtime.session));
    expect.soft(runtimeEventViewsForMap(project, project.maps[AWAY]!, restored, {}).map(view => view.event.id)).not.toContain(OTHER);
    expect(runtime.views().map(view => view.event.id)).toEqual([HOST, SELECTED]);
  });

  it("PASS control: explicit authored host ID removes only host, persistently rather than temporary erase", () => {
    const runtime = runtimeFixture(project);
    execute(m2("Remove Event", { eventId: HOST }), runtime, HOST);
    expect(runtime.views().map(view => view.event.id)).toEqual([SELECTED]);
    expect(runtime.session.removedEventIds?.[HOME]).toEqual([HOST]);
    expect(runtime.session.erasedEventIds ?? []).toEqual([]);
  });

  it("PASS control: spawned target uses its owner map, survives removal save/load, and can be recreated", () => {
    const runtime = runtimeFixture(project);
    execute(spawn(SPAWN, AWAY), runtime, HOST);
    expect(runtime.views(AWAY).map(view => view.event.id)).toContain(SPAWN);
    execute(m2("Remove Event", { eventId: SPAWN }), runtime, HOST);
    expect(runtime.views(AWAY).map(view => view.event.id)).toEqual([OTHER]);
    expect(runtime.session.spawnedEvents?.[SPAWN]).toBeUndefined();
    expect(runtime.session.eventLocations?.[SPAWN]).toBeUndefined();
    const restored = applySaveSnapshot(project, createSaveSnapshot(project, runtime.session));
    expect(runtimeEventViewsForMap(project, project.maps[AWAY]!, restored, {}).map(view => view.event.id)).toEqual([OTHER]);
    execute(spawn(SPAWN, AWAY, 8, 6), runtime, HOST);
    expect(runtime.views(AWAY).find(view => view.event.id === SPAWN)).toMatchObject({ x: 8, y: 6 });
    expect(runtime.views().map(view => view.event.id)).toEqual([HOST, SELECTED]);
  });

  it("PASS control: blank selection is not an implicit request to remove the host", () => {
    const runtime = runtimeFixture(project);
    const before = identityState(runtime);
    execute(m2("Remove Event", { eventId: "" }), runtime, HOST);
    expect(identityState(runtime)).toEqual(before);
  });

  it("RED: omitted target is not an explicit current-event mode and must not default to host", () => {
    const runtime = runtimeFixture(project);
    const before = identityState(runtime);
    execute(m2("Remove Event"), runtime, HOST);
    expect(identityState(runtime)).toEqual(before);
  });

  it("RED: unknown target cannot create a removal tombstone or mutate another identity", () => {
    const runtime = runtimeFixture(project);
    const before = identityState(runtime);
    execute(m2("Remove Event", { eventId: UNKNOWN }), runtime, HOST);
    expect(identityState(runtime)).toEqual(before);
  });
});
